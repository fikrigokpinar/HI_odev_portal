%% HESAPLAMALI İSTATİSTİK — ÖDEV: İki Yöntem GA Karşılaştırması
%  Adınız Soyadınız:
%  Numaranız:
%  Tarih:
%
%  NOT: Bu ödevle birlikte verilen fonksiyonlar:
%    - ga2grupv_biliniyorken.m   (varyans biliniyor → z tabanlı)
%    - ga2grup_varbilinmiyor_esit.m (varyans bilinmiyor eşit → havuzlanmış t)

%% SORU: MC Simülasyon ile İki Yöntem Karşılaştırması (100 puan)
%
% İki yığın ortalaması farkı (mu1-mu2) için iki farklı GA yöntemi var:
%   Yöntem 1: Varyanslar biliniyor → z tabanlı GA (ga2grupv_biliniyorken)
%   Yöntem 2: Varyanslar bilinmiyor ama eşit → havuzlanmış t (ga2grup_varbilinmiyor_esit)
%
% Görev:
%   5000 Monte Carlo tekrarı ile her iki yöntemin:
%     a) Ortalama GA genişliğini (ust-alt) hesaplayınız
%     b) Kapsama olasılığını (gerçek mu1-mu2 farkının GA içinde kalma oranı) hesaplayınız
%
% Aşağıdaki DURUMLAR için sonuçları raporlayınız:
%   Durum 1: n1=20, n2=20, sigma1=5, sigma2=5,  mu1=50, mu2=50
%   Durum 2: n1=20, n2=20, sigma1=5, sigma2=10, mu1=50, mu2=50
%   Durum 3: n1=50, n2=50, sigma1=5, sigma2=5,  mu1=50, mu2=50
%   Durum 4: n1=10, n2=30, sigma1=5, sigma2=5,  mu1=50, mu2=50
%
% Parametreler:
alfa = 0.05;
ds = 5000;      % MC tekrar sayısı
gercek_fark = 0; % mu1 - mu2

durumlar = [
%   n1   n2  sigma1 sigma2  mu1   mu2
    20   20   5      5      50    50;
    20   20   5      10     50    50;
    50   50   5      5      50    50;
    10   30   5      5      50    50;
];

% >>> KODUNUZU BURAYA YAZINIZ <<<
% Her durum için:
%   1) ds kez normrnd ile örnekler üretin
%   2) Her iki GA yöntemiyle alt-üst hesaplayın
%   3) GA genişliği ve kapsama sayısını toplayın
%   4) Sonuçları tablo halinde yazdırın

% İpuçları:
%   x1 = normrnd(mu1, sigma1, 1, n1);
%   x2 = normrnd(mu2, sigma2, 1, n2);
%   [alt_z, ust_z] = ga2grupv_biliniyorken(x1, x2, sigma1, sigma2, alfa);
%   [alt_t, ust_t] = ga2grup_varbilinmiyor_esit(x1, x2, alfa);
%   kapsama: gercek_fark >= alt && gercek_fark <= ust


% RAPORLAMA: Sonuçlarınızı aşağıdaki formatta yazdırınız:
% fprintf('Durum %d: z-GA genişlik=%.3f kapsama=%.3f | t-GA genişlik=%.3f kapsama=%.3f\n', ...);

% YORUM: Her durum için aşağıdaki soruları cevaplayınız (yorum satırı):
%   1) Hangi yöntem daha dar GA veriyor?
%   2) Kapsama olasılıkları nominal (%95) düzeye yakın mı?
%   3) Varyanslar eşit olmadığında (Durum 2) ne oluyor?
%   4) Örnek çapı dengeli olmadığında (Durum 4) ne oluyor?
% >>> YORUMUNUZU BURAYA YAZINIZ <<<

