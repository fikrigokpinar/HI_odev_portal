function [alt, ust]=ga2grupv_biliniyorken(x1,x2,sigma1,sigma2,alfa)
n1=length(x1);n2=length(x2);
s12=sqrt(sigma1^2/n1+sigma2^2/n2);
zalfa2=norminv(1-alfa/2);
ortf=mean(x1)-mean(x2);
alt=ortf-s12*zalfa2;
ust=ortf+s12*zalfa2;
