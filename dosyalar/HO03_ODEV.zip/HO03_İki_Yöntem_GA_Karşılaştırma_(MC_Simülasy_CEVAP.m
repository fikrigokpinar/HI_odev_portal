%% CEVAP ANAHTARI — İki Yöntem GA Karşılaştırması (MC)

alfa = 0.05;
ds = 5000;
gercek_fark = 0;

durumlar = [20 20 5 5 50 50; 20 20 5 10 50 50; 50 50 5 5 50 50; 10 30 5 5 50 50];

for d = 1:size(durumlar,1)
    n1=durumlar(d,1); n2=durumlar(d,2);
    sigma1=durumlar(d,3); sigma2=durumlar(d,4);
    mu1=durumlar(d,5); mu2=durumlar(d,6);

    kapsama_z=0; kapsama_t=0;
    gen_z=0; gen_t=0;

    for i=1:ds
        x1=normrnd(mu1,sigma1,1,n1);
        x2=normrnd(mu2,sigma2,1,n2);

        [alt_z,ust_z]=ga2grupv_biliniyorken(x1,x2,sigma1,sigma2,alfa);
        [alt_t,ust_t]=ga2grup_varbilinmiyor_esit(x1,x2,alfa);

        gen_z=gen_z+(ust_z-alt_z);
        gen_t=gen_t+(ust_t-alt_t);

        if gercek_fark>=alt_z && gercek_fark<=ust_z
            kapsama_z=kapsama_z+1;
        end
        if gercek_fark>=alt_t && gercek_fark<=ust_t
            kapsama_t=kapsama_t+1;
        end
    end

    fprintf('Durum %d: z-GA genislik=%.3f kapsama=%.3f | t-GA genislik=%.3f kapsama=%.3f\n', ...
        d, gen_z/ds, kapsama_z/ds, gen_t/ds, kapsama_t/ds);
end

% Yorum:
% Durum 1 (eşit var, eşit n): Her iki yöntem benzer, kapsama ~0.95
% Durum 2 (farklı var): z-GA sigma bilgisi kullandığı için daha doğru
% Durum 3 (büyük n): GA daha dar, kapsama yine ~0.95
% Durum 4 (dengesiz n): Havuzlanmış t biraz sapabilir
