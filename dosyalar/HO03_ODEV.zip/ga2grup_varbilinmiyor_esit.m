function [alt, ust]=ga2grup_varbilinmiyor_esit(x1,x2,alfa)
% Varyanslar bilinmiyor ama eşit kabul edilir → havuzlanmış t
n1=length(x1); n2=length(x2);
Sp2=(var(x1)*(n1-1)+var(x2)*(n2-1))/(n1+n2-2);
s12=sqrt(Sp2*(1/n1+1/n2));
talfa2=tinv(1-alfa/2, n1+n2-2);
ortf=mean(x1)-mean(x2);
alt=ortf-s12*talfa2;
ust=ortf+s12*talfa2;
