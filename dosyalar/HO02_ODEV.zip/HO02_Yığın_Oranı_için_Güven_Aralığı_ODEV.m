%% HESAPLAMALI İSTATİSTİK — ÖDEV: Yığın Oranı Güven Aralığı
%  Adınız Soyadınız:
%  Numaranız:
%  Tarih:

%% SORU 1: Oran GA Fonksiyonu (40 puan)
% Yığın oranı p için güven aralığı hesaplayan bir fonksiyon yazınız.
%
% Fonksiyon imzası:
%   function [alt, ust] = oran_ga(x, alfa)
%
% Girdiler:
%   x    : 0/1 vektörü (başarılı=1, başarısız=0)
%   alfa : anlamlılık düzeyi
%
% Çıktılar:
%   alt : güven aralığı alt sınırı
%   ust : güven aralığı üst sınırı
%
% Formül:
%   p_sapka ± z_{alfa/2} * sqrt(p_sapka*(1-p_sapka)/n)
%
% İpuçları:
%   - p_sapka = mean(x)  (x 0/1 ise bu oranı verir)
%   - z_{alfa/2} = norminv(1-alfa/2)

% >>> CEVABINIZI BURAYA YAZINIZ <<<


%% SORU 2: Uygulama (60 puan)
% Bir anket çalışmasında 200 kişiden 126'sı "Evet" demiştir.

n = 200;
evet_sayisi = 126;
x = [ones(1, evet_sayisi), zeros(1, n - evet_sayisi)];
alfa = 0.05;

% a) Oran GA fonksiyonunuzu kullanarak %95 güven aralığını bulunuz:
% >>> CEVABINIZI BURAYA YAZINIZ <<<


% b) Güven aralığını ve yorumunuzu yazınız:
%    - p_sapka nedir?
%    - GA ne anlama gelir? Oran %50'den farklı mı?
% >>> YORUMUNUZU BURAYA YAZINIZ <<<

