%% CEVAP ANAHTARI — Yığın Oranı Güven Aralığı

%% SORU 1: Fonksiyon
function [alt, ust] = oran_ga(x, alfa)
p_sapka = mean(x);
n = length(x);
zalfa2 = norminv(1-alfa/2);
fark = zalfa2 * sqrt(p_sapka*(1-p_sapka)/n);
alt = p_sapka - fark;
ust = p_sapka + fark;
end

%% SORU 2: Uygulama
n = 200;
evet_sayisi = 126;
x = [ones(1, evet_sayisi), zeros(1, n - evet_sayisi)];
alfa = 0.05;

[alt, ust] = oran_ga(x, alfa);
fprintf('p_sapka = %.4f\n', mean(x));
fprintf('GA = [%.4f, %.4f]\n', alt, ust);

% Yorum: p_sapka = 0.63, GA = [0.563, 0.697]
% 0.50 GA dışında kaldığından oran %50'den anlamlı olarak farklı.
